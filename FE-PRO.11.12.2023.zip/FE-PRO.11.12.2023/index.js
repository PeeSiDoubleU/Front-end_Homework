// Повторял задания которые делали на уроке. p.s Домашка ниже!

// 1.Вывести в консоль все чётные числа от 10 до нуля кроме 4

// for (let i = 10; i >= 0 ; i--) {

//    if (i === 4) {
//       continue
//    }
//    if (i % 2 === 0) {
//       console.log(i);
//    }
// }


// 2.Создать переменную raz (число) в зависимости от значений этой переменной.
// Cформировать строку 'lalalalalala'

// let raz = 6;
// let sum = 0;
// let str = '';

// for (i = sum; i < raz ; i++) {
//    str = str + 'la'
// }
// console.log(str);



// 3.Пользователь вводит число n вывести в консоль сумму чисел от 1 до n

// let n = prompt("Введите число");
// let sum = 0;

// if (!isNaN(n)) {
//    n = Number(n);
// }

// for (let i = 1; i <= n; i++) {
//    sum = sum + i;
// }

// console.log(sum);


// 4.Пользоватеь вводит число n потом m, вывести числа от n до m

// let n = prompt("Введите число");
// let m = prompt("Введите число");

// if (!isNaN(n) && !isNaN(m)) {
//    n = Number(n);
//    m = Number(m);
// }

// if (n < m) {
//    for (let i = n; i <= m; i++) {
//       console.log(i);
//    }
// } else if (m < n) {
//    for (i = n; i >= m; i--) {
//       console.log(i);
//    }
// }



// ДОМАШКА //

// 1. Пользователь вводит год своего рождения, вывести
// информацию о возрасте пользователя в разные года
// до текущего. Например, вводим «2003». Вывод: «в
// 2003 было 1 год», «в 2004 было 2 год», «в 2005 было
// 3 год» и т.д.

// let dateOfBirth = prompt('Введите дату рождения')
// let thisYear = 2023;

// if (!isNaN(dateOfBirth)) {
//    dateOfBirth = Number(dateOfBirth);
// }


// for (let i = 1; dateOfBirth < thisYear; i++) {
//    dateOfBirth++;
//    console.log(`В ${dateOfBirth} вам было ${i} лет `);
// }

// 2. Написать программу, в которой пользователя просят ввести числа 5 раз. Причем
// каждое последующее число должно быть больше предыдущего, иначе вывести
// ошибку.

// let raz = 5;
// let sum = 0;

// for (let i = 0; raz > i; i++ ) {

//    let userNum = prompt('Введите число')

//    if (isNaN(userNum)) {
//       alert('Введите число:')
//       continue
//    }

//    userNum = Number(userNum);


//    if (userNum <= sum) {
//       alert ('Каждое следующее число должно быть больше')
//       continue
//    }
//    console.log(userNum);
//    sum = userNum;
// }




